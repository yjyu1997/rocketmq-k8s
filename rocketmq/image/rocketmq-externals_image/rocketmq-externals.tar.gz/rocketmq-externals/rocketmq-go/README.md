# RocketMQ Go SDK
some code refer to below repos:
* https://github.com/didapinchegit/go_rocket_mq
* https://github.com/sevennt/go_rocket_mq/